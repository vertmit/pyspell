from .spellcheck import load_dictionary
from .spellcheck import spell_check
from .spellcheck import correct_word
from .spellcheck import correct_sentance
from .spellcheck import dictionary

__all__ = ['load_dictionary', 'spell_check', 'correct_word', 'correct_sentance', 'dictionary']