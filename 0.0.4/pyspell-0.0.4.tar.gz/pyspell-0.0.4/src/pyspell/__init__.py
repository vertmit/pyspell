from .spellcheck import *

__all__ = ['load_dictionary', 'spell_check', 'correct_word', 'correct_sentance', 'dictionary']